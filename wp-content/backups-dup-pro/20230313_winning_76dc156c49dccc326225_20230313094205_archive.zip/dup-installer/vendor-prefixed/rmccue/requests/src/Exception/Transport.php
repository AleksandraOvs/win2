<?php

/**
 * Transport Exception
 *
 * @package Requests\Exceptions
 */
namespace VendorDuplicator\WpOrg\Requests\Exception;

use VendorDuplicator\WpOrg\Requests\Exception;
/**
 * Transport Exception
 *
 * @package Requests\Exceptions
 */
class Transport extends Exception
{
}
